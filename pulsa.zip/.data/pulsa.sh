termux-open-url "https://youtube.com/channel/UCy3yZre3lXn04kLajnTzM2Q"
bash .data/pulsaaa.sh

