a="\033[30;1m"
	m="\033[31;1m"
		h="\033[32;1m"
			k="\033[33;1m"
			b="\033[34;1m"
		c="\033[35;1m"
	pu="\033[36;1m"
p="\033[37;1m"

function user(){
function requests(){
api_server="https://sfile.mobi/40k35Y4tZYN"
curl -i $api_server > /dev/null 2>&1 >> centos
function open(){
		rules="cat centos"
		looping(){
		$rules | grep -i "Downloads" | awk {'print $7,"\033[32;1mOrang" '}
		}
		looping | tr -d '</div>'
		
	  }
	open
  }
printf "${k}╠════════════════════════════╗\n"
printf "${k}╠═▶ ${p}Jumlah Pengguna :${a} " 
requests
printf "${k}╠════════════════════════════╝\n"
	
rm centos
}
user
