#!/bin/python
import os
import sys
import socket
from time import sleep

def t(nn,t_):
        print(t_)
        print('')
        for i in range(0,33):
                i+=1
                txt='\033[1;32m▒'*42
                f=i*'\033[1;31m▊'
                tt=i*3+1
                ttt=str(tt)
                print(txt+'┊'+ttt+'%',end='\r')
                print('Mr.Fuck ┊{}'.format(f),end='\r')
                sleep(nn)
        print('')

t(0.1,'\n\t   \033[1;31m     [ Tunggu Sebentar ]')
t(0.1,'\n\t   \033[1;31m   [ Memproses Data Nomor ]')
t(0.1,'\n\t   \033[1;31m   [ Memproses Data pulsa ]')
t(0.1,'\n\t   \033[1;31m [ menghubungkan semua Data ]')
print()
